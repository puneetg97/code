import { TestBed } from '@angular/core/testing';

import { DftSellerAddProductsService } from './dft-seller-add-products.service';

describe('DftSellerAddProductsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DftSellerAddProductsService = TestBed.get(DftSellerAddProductsService);
    expect(service).toBeTruthy();
  });
});
