import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DftSellerRemoveProductsComponent } from './dft-seller-remove-products.component';

describe('DftSellerRemoveProductsComponent', () => {
  let component: DftSellerRemoveProductsComponent;
  let fixture: ComponentFixture<DftSellerRemoveProductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DftSellerRemoveProductsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DftSellerRemoveProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
