import { TestBed } from '@angular/core/testing';

import { DftSellerRemoveProductsService } from './dft-seller-remove-products.service';

describe('DftSellerRemoveProductsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DftSellerRemoveProductsService = TestBed.get(DftSellerRemoveProductsService);
    expect(service).toBeTruthy();
  });
});
