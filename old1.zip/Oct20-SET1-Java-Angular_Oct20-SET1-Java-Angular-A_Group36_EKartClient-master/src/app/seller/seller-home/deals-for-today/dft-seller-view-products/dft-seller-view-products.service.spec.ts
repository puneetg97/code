import { TestBed } from '@angular/core/testing';

import { DftSellerViewProductsService } from './dft-seller-view-products.service';

describe('DftSellerViewProductsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DftSellerViewProductsService = TestBed.get(DftSellerViewProductsService);
    expect(service).toBeTruthy();
  });
});
