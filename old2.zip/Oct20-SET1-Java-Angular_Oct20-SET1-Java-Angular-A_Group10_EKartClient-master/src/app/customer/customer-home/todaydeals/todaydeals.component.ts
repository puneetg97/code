import { Component, OnInit } from '@angular/core';
import { Seller } from 'src/app/shared/models/seller';
import { Deal } from 'src/app/shared/models/deal';
import{TodaydealService} from 'src/app/customer/customer-home/todaydeals/todaydeals.service'
import { Product } from 'src/app/shared/models/product';

@Component({
  selector: 'app-todaydeals',
  templateUrl: './todaydeals.component.html',
  styles:['.Center{ width:70%; height:70%; position: fixed; top:50%; left:50%; margin-top: -200px; margin-left: -300px;}'],
  styleUrls: ['./todaydeals.component.css']
 
  
})
export class TodaydealsComponent implements OnInit {
  p:Number=1;
  count: Number=10;
  // Pagination
  seller: Seller
  //seller object
  // ####### Product in deals list ###########
  productsOnDeal: Deal []
  ProductsOnDealDisplay: Deal[] =[]
 
 // ####### Product in deals list ###########
 removeSuccessMessage: any;
  removeErrorMessage: any;
  displayProduct: Product;
  addressToDisplay: any;
  
  // remove Deal messages
  
  isOn:any = false;
  isEnded:any = false;
  toStart:any = false;


  
  
  

  constructor(private todaydealService:TodaydealService) { }

  ngOnInit() {

    this.seller = JSON.parse(sessionStorage.getItem("seller"));
    this.viewProductsInDeals();
    this.removeSuccessMessage = null;
    this.removeErrorMessage = null;
   
    

  }


  

  viewProductsInDeals(){
    this.todaydealService.customerProductsOnDeals()
    .subscribe(deal =>{
      this.productsOnDeal = deal;
      this.ProductsOnDealDisplay = this.productsOnDeal
      
    })

  
  }
  displayProductDetails(product: Product){
    
    this.addressToDisplay = null;
    this.displayProduct=product;
  }


}