import { Component, OnInit, Input } from '@angular/core';
import { Seller } from 'src/app/shared/models/seller';
import { DealForTodayService } from './deal-for-today.service';
import { Product } from 'src/app/shared/models/product';
import {Deal} from 'src/app/shared/models/deal';


@Component({
  selector: 'app-seller-add-dealfortoday',
  templateUrl: './seller-add-dealfortoday.component.html',
  styleUrls: ['./seller-add-dealfortoday.component.css']
})
export class SellerAddDealfortodayComponent implements OnInit {

  errorMessage: string = "";
  successMessage: string = "";
  seller: Seller  
  productList: Product[]
  showDealForm: boolean;
  dealToBeAdded: Deal  

  // 
  StartDate: Date
  EndDate: Date
  Discount: number
  message: string = "";
  newProductList : Product[]
  showProductTable: Boolean


// ####### noDealProducts objects #######
  productsNotInDeals: Product[]
  productsNotInDealsToDisplay: Product[] = [];
  // ####### noDealProducts objects #######

  sellerDealsProducts:Product[] =[]
  p:Number=1;
  count: Number=10;

  constructor(private DealForTodayService: DealForTodayService) { }

  ngOnInit() {
    this.productList = JSON.parse(sessionStorage.getItem("sellerProducts"));
    this.seller = JSON.parse(sessionStorage.getItem("seller"));
    this.showDealForm = true
    this.newProductList=this.productList
    this.showProductTable=false;
    this.viewProductsNotInDeals();
    // this.successMessage = null;
    this.errorMessage=null;
  }
  
  // test(){
  // this.contest();
  // }
  // contest(){ 
    
  //   console.log(this.sellerDealsProducts)
  // }

  cancelform(){
    this.showProductTable = false;
    this.showDealForm = true;

  }

  addToDeal(product: Product) {
    this.dealToBeAdded = new Deal
    this.dealToBeAdded.product = product
    this.dealToBeAdded.sellerEmail = this.seller.emailId
    this.showDealForm = false;
    this.showProductTable=true;
    this.viewProductsNotInDeals();
  }


  viewProductsNotInDeals(){
    this.DealForTodayService.productsNotOnDeals(this.seller.emailId)
    .subscribe(products =>{
      this.productsNotInDeals = products;
      this.productsNotInDealsToDisplay = this.productsNotInDeals
      sessionStorage.setItem("noDealProducts", JSON.stringify(this.productsNotInDealsToDisplay));
    });
    
  }

  addDeal(deal: Deal) {
    this.dealToBeAdded.product.sellerEmailId= this.seller.emailId
    this.dealToBeAdded.dealDiscount = this.Discount
    this.dealToBeAdded.sellerEmail = this.seller.emailId
    this.dealToBeAdded.dealStartAt = this.StartDate
    this.dealToBeAdded.dealEndsAt = this.EndDate
  
    
     console.log(this.dealToBeAdded.product)
    
    this.DealForTodayService.dealForDay(this.dealToBeAdded)
    .subscribe((message) => {
      this.successMessage = message
    }, error =>this.errorMessage = <any>error
  )
    if(this.successMessage!=null){
    this.showDealForm = true; // hiding deal adding form
    this.showProductTable = false;//display products table 
    this.viewProductsNotInDeals()
    this.ngOnInit();
  }

}
   
}