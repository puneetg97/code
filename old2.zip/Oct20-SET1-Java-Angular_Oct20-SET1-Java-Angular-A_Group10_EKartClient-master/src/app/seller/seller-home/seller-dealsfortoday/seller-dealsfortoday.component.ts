import { Component, OnInit } from '@angular/core';
import { Seller } from 'src/app/shared/models/seller';
import { Deal } from 'src/app/shared/models/deal';
import { ViewDealsService } from './view-deals.service'
import { Product } from 'src/app/shared/models/product';



@Component({
  selector: 'app-seller-dealsfortoday',
  templateUrl: './seller-dealsfortoday.component.html',
  styles:['.Center{ width:70%; height:70%; position: fixed; top:50%; left:50%; margin-top: -200px; margin-left: -300px;}'],
  styleUrls: ['./seller-dealsfortoday.component.css']
 
  
})
export class SellerDealsfortodayComponent implements OnInit {
  p:Number=1;
  count: Number=10;
  // Pagination
  seller: Seller
  //seller object
  // ####### Product in deals list ###########
  productsOnDeal: Deal []
  ProductsOnDealDisplay: Deal[] =[]
 
  // ####### Product in deals list ###########
  removeSuccessMessage: any;
  removeErrorMessage: any;
  displayProduct: Product;
  addressToDisplay: any;
  
  // remove Deal messages
  now:any=Date.now();


  constructor(private ViewDealsService:ViewDealsService) { }

  ngOnInit() {

    this.seller = JSON.parse(sessionStorage.getItem("seller"));
    this.viewProductsInDeals();
    //  console.log(this.now)
    this.removeSuccessMessage = null;
    this.removeErrorMessage = null;
  }

 
  displayProductDetails(product: Product){
    
    this.addressToDisplay = null;
    this.displayProduct=product;
  }

  viewProductsInDeals(){
    this.ViewDealsService.productsOnDeals(this.seller.emailId)
    .subscribe(deal =>{
      this.productsOnDeal = deal;
      this.ProductsOnDealDisplay = this.productsOnDeal
      
    })

  
  }

  removeFrom(deal:Deal){
   
    this.ViewDealsService.removeDeal(deal)
    .subscribe(
      message=>{
       this.removeSuccessMessage = message;
      }, error=> this.removeErrorMessage=<any>error
    )
 
   this.viewProductsInDeals();
   this.ngOnInit();
 
  }

}
