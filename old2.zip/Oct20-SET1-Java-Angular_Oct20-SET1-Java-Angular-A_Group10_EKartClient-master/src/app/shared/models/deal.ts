import { Product } from './product';

export class Deal{
    dealId: number;
    product: Product;
    dealDiscount: number;
    dealStartAt: any;
    dealEndsAt: any;
    sellerEmail: string;
    successMessage: string;
    errorMessage:string;
    remove: Boolean;
    dealStatus : string;

}