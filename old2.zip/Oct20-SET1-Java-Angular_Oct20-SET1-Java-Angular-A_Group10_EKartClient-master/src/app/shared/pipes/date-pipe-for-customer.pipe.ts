import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'datePipeForCustomer'
})
export class DatePipeForCustomerPipe implements PipeTransform {

  transform(value: any): any {
    let data: string = value+"";
    let dates: string[] = data.split(",");

    if(dates.length==5){
      data+=",0";
      dates=data.split(",");
    }
    let date = new Date(parseInt(dates[0]),
        parseInt(dates[1])-1,
        parseInt(dates[2]),
        parseInt(dates[3]),
        parseInt(dates[4]),
        parseInt(dates[5]));

    return date;
    
  }

}
